#pragma once

#include "../libs/get/src/Get.hpp"

#include "../libs/chesto/src/Button.hpp"
#include "../libs/chesto/src/ImageElement.hpp"
#include "../libs/chesto/src/ListElement.hpp"
#include "../libs/chesto/src/TextElement.hpp"
#include "../libs/chesto/src/EKeyboard.hpp"

#include "AppCard.hpp"
#include "AppDetails.hpp"
#include "Sidebar.hpp"

#include <random>
#include <list>

#define TOTAL_SORTS 5 // alphabetical (with updates at top), downloads, last updated, size, shuffled
#define RECENT 0
#define POPULARITY 1
#define ALPHABETICAL 2
#define SIZE 3
#define RANDOM 4

#define PANE_WIDTH SCREEN_HEIGHT

class AppList : public ListElement
{
public:
	AppList(Get* get, Sidebar* sidebar);

	bool process(InputEvents* event);
	void render(Element* parent);
	void update();

	Get* get = NULL;
	Sidebar* sidebar = NULL;

	void toggleKeyboard();
	void cycleSort();
	void reorient();
	void toggleAudio();

	bool touchMode = true;
	bool needsUpdate = false;

	// the total number of apps displayed in this list
	int totalCount = 0;

	// default number of items per row TODO: save this value as config
	int R = 3;

	int sortMode = RECENT;
	bool useBannerIcons = true;

	void launchSettings(bool isCredits);
	bool hideSidebar = false;
	EKeyboard keyboard;

	// posiciona el titulo/subtitulo de la seccion (arriba, fijo) y todos los
	// botones de accion (abajo, en la franja compartida con Sidebar). Se
	// llama desde update() para que ambos grupos usen siempre las mismas
	// coordenadas, sin importar cuanto haya scrolleado la lista de tarjetas.
	void positionChrome();

private:
	bool sortCompare(const Package& left, const Package& right);
	std::random_device randDevice;

	void keyboardInputCallback();

	// the title of this category (from the sidebar)
	static CST_Color black, gray, red, lighterRed;
	static std::string sortingDescriptions[TOTAL_SORTS];

	TextElement sortBlurb;
	TextElement category;
	Button quitBtn;
	Button sortBtn;
	Button keyboardBtn;
	Button backspaceBtn;
	TextElement nowPlayingText;

#if defined(MUSIC)
	ImageElement nowPlayingIcon;
	Button muteBtn;
	ImageElement muteIcon;
	ImageElement unmuteIcon;
	Button toolsBtn;
	std::vector<std::string> musicInfo;
#endif

	// list of visible app cards
	std::list<AppCard> appCards;
};
