#pragma once

#include "ImageElement.hpp"
#include "TextElement.hpp"

class Button : public Element
{
public:
	Button(std::string text, int button, bool dark = false, int size = 20, int width = 0, float iconScale = 1.5f);

	void render(Element* parent);
	bool process(InputEvents* event);

	void updateBounds();
	void updateText(const std::string &inc_text);
	const std::string getText();

	std::string myLastSeenGamepad = "";

	TextElement text;
	static std::string getControllerButtonImageForPlatform(int button, bool isGray, bool isOutline);

	// a width we set the button to regardless of inner text
	int fixedWidth = 0;

	// whether the button is dark or light themed
	bool dark = false;

	// boton "plano": sin recuadro de fondo, solo icono + texto sobre lo que
	// haya detras. lightContent = true -> texto/iconos claros (fondo oscuro).
	// textColor (opcional): color del texto por puntero (sigue los cambios de tema)
	void setFlat(bool flatMode, bool lightContent, CST_Color* textColor = nullptr);
	bool flat = false;
	CST_Color* flatTextColor = nullptr;
	
private:
	static CST_Color colors[2];
	/// the physical button to activate this button
	int physical = -1;

	ImageElement icon;

	// que tan grande es el icono del boton fisico respecto al alto del
	// texto (1.5 = tamano original). Permite agrandar el icono solo en
	// botones puntuales sin afectar al resto de la app.
	float iconScale = 1.5f;

	bool shouldRenderGlossy();
};
