#include "NspAutoInstall.hpp"
#include "InstallEngine.hpp"
#include "HttpByteSource.hpp"
#include "../Cancel.hpp"
#include "../Cancel.hpp"

#include <cstdio>
#include <cstdlib>
#include <sys/stat.h>

namespace nspinstall {

bool DeleteInstallFile(const std::string &root_path, const std::string &relative_nsp_path) {
    if (relative_nsp_path.empty()) {
        return true;
    }

    // nunca salir de la raiz de la SD
    if (relative_nsp_path.find("..") != std::string::npos) {
        printf("[nspinstall] ruta de instalacion sospechosa, no se borra: %s\n", relative_nsp_path.c_str());
        return false;
    }

    std::string clean = relative_nsp_path;
    while (!clean.empty() && clean.front() == '/') {
        clean.erase(0, 1);
    }
    if (clean.empty() || clean.back() == '/') {
        return false; // es una carpeta, no un archivo
    }

    std::string root = root_path;
    if (!root.empty() && root.back() != '/') {
        root += '/';
    }
    const std::string full_path = root + clean;

    struct stat st{};
    if (stat(full_path.c_str(), &st) != 0) {
        return true; // ya no existe
    }
    if (S_ISDIR(st.st_mode)) {
        printf("[nspinstall] %s es una carpeta, no se borra\n", full_path.c_str());
        return false;
    }

    const bool ok = (std::remove(full_path.c_str()) == 0);
    printf("[nspinstall] borrar %s: %s\n", full_path.c_str(), ok ? "OK" : "FALLO");
    return ok;
}

AutoInstallResult InstallNspIfRequested(const std::string &root_path,
                                         const std::string &relative_nsp_path,
                                         bool install_to_nand,
                                         AutoInstallProgress progress) {
    AutoInstallResult result;

    // Paso 3 del flujo pedido: si el repo.json no trae la orden de
    // instalación, no hacemos absolutamente nada.
    if (relative_nsp_path.empty()) {
        result.nothing_to_do = true;
        result.success = true; // no es un fallo, simplemente no aplica
        return result;
    }

    printf("[nspinstall] repo.json pide instalar: %s\n", relative_nsp_path.c_str());

    // Normaliza la ruta: acepta tanto "carpeta/archivo.nsp" como "/carpeta/archivo.nsp"
    std::string clean = relative_nsp_path;
    if (!clean.empty() && clean.front() == '/') {
        clean.erase(0, 1);
    }

    std::string root = root_path;
    if (!root.empty() && root.back() != '/') {
        root += '/';
    }

    const std::string full_path = root + clean;

    struct stat st{};
    if (stat(full_path.c_str(), &st) != 0) {
        printf("[nspinstall] stat() fallo para %s\n", full_path.c_str());
        result.success = false;
        result.message = "No se encontró el NSP a instalar tras la extracción:\n" + full_path;
        return result;
    }
    printf("[nspinstall] nsp encontrado (%lld bytes): %s\n", (long long)st.st_size, full_path.c_str());

    ::nspinstall::InstallConfig config;
    config.dest_storage_id = install_to_nand ? NcmStorageId_BuiltInUser : NcmStorageId_SdCard;
    config.ignore_req_fw   = true;
    config.reinstall_ncas  = false;

    ::nspinstall::InstallResult install_res = ::nspinstall::InstallFromLocalFile(
        full_path, config,
        [&progress](const ::nspinstall::InstallProgress &p) {
            if (progress) {
                progress(p.bytes_done, p.bytes_total, p.current_nca, p.preparing);
            }
        });

    printf("[nspinstall] InstallFromLocalFile termino: %s\n", install_res.success ? "OK" : "FALLO");

    result.success = install_res.success;
    if (install_res.success) {
        result.message = "INSTALACION EXITOSA";
    } else if (libget_cancelled()) {
        result.cancelled = true;
        result.message = "Instalacion cancelada por el usuario.";
    } else {
        result.message = "No se pudo instalar el NSP automáticamente:\n" + install_res.error_message;
    }
    return result;
}

AutoInstallResult InstallNspFromUrl(const std::string &url,
                                    bool install_to_nand,
                                    AutoInstallProgress progress) {
    AutoInstallResult result;
    if (url.empty()) {
        result.nothing_to_do = true;
        result.success = true;
        return result;
    }

#ifdef NETWORK_MOCK
    result.message = "Instalacion directa no disponible en esta plataforma";
    return result;
#else
    printf("[nspinstall] instalacion directa desde: %s\n", url.c_str());

    HttpByteSource source(url, 4);
    std::string err;
    if (!source.Open(err)) {
        printf("[nspinstall] no se pudo abrir la fuente: %s\n", err.c_str());
        result.message = "No se pudo iniciar la instalacion directa:\n" + err;
        return result;
    }
    printf("[nspinstall] tamano remoto: %llu bytes\n", (unsigned long long)source.Size());

    ::nspinstall::InstallConfig config;
    config.dest_storage_id = install_to_nand ? NcmStorageId_BuiltInUser : NcmStorageId_SdCard;
    config.ignore_req_fw   = true;
    config.reinstall_ncas  = false;

    ::nspinstall::InstallResult install_res = ::nspinstall::InstallFromSource(
        source, config,
        [&progress](const ::nspinstall::InstallProgress &p) {
            if (progress) {
                progress(p.bytes_done, p.bytes_total, p.current_nca, p.preparing);
            }
        });

    printf("[nspinstall] InstallFromSource (url) termino: %s\n", install_res.success ? "OK" : "FALLO");
    result.success = install_res.success;
    if (install_res.success)
        result.message = "INSTALACION EXITOSA";
    else if (libget_cancelled()) {
        result.cancelled = true;
        result.message = "Instalacion cancelada por el usuario.";
    } else
        result.message = "No se pudo instalar el NSP automáticamente:\n" + install_res.error_message;
    return result;
#endif
}

}
