#pragma once

#include <cstdint>
#include <functional>
#include <string>

#include <switch/services/ncm.h>

#include "ByteSource.hpp"

namespace nspinstall {

struct InstallProgress {
    std::uint64_t bytes_done        = 0;
    std::uint64_t bytes_total       = 0;
    std::string   current_nca;
    std::uint32_t nca_index         = 0;
    std::uint32_t nca_count         = 0;
    bool          decompressing     = false;
    // true durante CreatePlaceholder(): NCM reserva de antemano todo el
    // espacio del archivo antes de escribir contenido real, y esa reserva
    // no tiene ninguna forma de reportar progreso incremental (es una sola
    // llamada bloqueante). Para archivos grandes puede tardar bastante, y
    // sin este aviso la UI se queda en "0%" sin ninguna señal de que sigue
    // trabajando.
    bool          preparing         = false;
};

using ProgressCallback = std::function<void(const InstallProgress &)>;

struct InstallResult {
    bool          success = false;
    std::string   error_message;
    std::uint64_t title_id = 0;
};

struct InstallConfig {
    NcmStorageId dest_storage_id = NcmStorageId_SdCard;
    bool         ignore_req_fw   = true;
    bool         reinstall_ncas  = false;
};

// Instala desde cualquier fuente de bytes (archivo local, o internet con HTTP Range).
// La fuente debe ser un NSP o NSZ (contenedor PFS0).
InstallResult InstallFromSource(ByteSource &source,
                                 const InstallConfig &config,
                                 ProgressCallback progress = nullptr);

InstallResult InstallFromLocalFile(const std::string &file_path,
                                    const InstallConfig &config,
                                    ProgressCallback progress = nullptr);

InstallResult InstallNsp(const std::string &file_path,
                          const InstallConfig &config,
                          ProgressCallback progress);

}
