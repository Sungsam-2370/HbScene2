#include "./repos/Repo.hpp"
#include "Utils.hpp"
#include "ZipUtil.hpp"
#include "./repos/constants.h"
#include "rapidjson/document.h"
#include "rapidjson/istreamwrapper.h"
#include <algorithm>
#include <fstream>
#include <iostream>
#include <sys/stat.h>
#include <unistd.h>
#include <unordered_set>
#include <vector>
#define u8 uint8_t

#if defined(__WIIU__)
// include xml files for legacy hb app store support
#include "tinyxml.h"
#endif

Package::Package(int state)
{
	this->pkg_name = "?";
	this->title = "???";
	this->author = "Unknown";
	this->version = "0.0.0";
	this->short_desc = "N/A";
	this->long_desc = "N/A";

	this->license = "";
	this->changelog = "";
	this->url = "";
	this->updated = "";
	this->updated_timestamp = 0;

	this->download_size = 0;
	this->extracted_size = 0;
	this->downloads = 0;

	this->category = "_all";
	this->binary = "none";

	this->status = state;
	this->screens = 0;
}

Package::~Package() = default;

std::string Package::toString() const
{
	return "[" + this->pkg_name + "] (" + this->version + ") \"" + this->title + "\" - " + this->short_desc;
}

bool Package::downloadZip(std::string_view tmp_path, float*, bool resume, int zipIndex, int zipTotal) const
{
	if (libget_status_callback != nullptr)
		libget_status_callback(STATUS_DOWNLOADING, zipIndex, zipTotal);

	// fetch zip file to tmp directory using curl
	printf("--> Downloading %s to %s%s\n", this->pkg_name.c_str(), tmp_path.data(), resume ? " (resuming)" : "");
	auto zipUrl = this->mRepo->getZipUrl(*this);

	if (zipUrl.empty()) {
		printf("--> ERROR: No download url found for %s\n", this->pkg_name.c_str());
		return false;
	}

	std::string downloadPath = std::string(tmp_path) + this->pkg_name + getUrlFileExt();
	
	// passing metadata allows us to note some headers for resume support
	download_metadata_t metadata = {};
	metadata.content_length = this->download_size;
	
	bool success = downloadFileToDiskWithMetadata(zipUrl, downloadPath, resume, &metadata);
	
	// if the download filed, but some data was received, record any metadata
	// (saves whether or not resume was requested)
	if (!success)
	{
		struct stat file_info = {};
		if (stat(downloadPath.c_str(), &file_info) == 0 && file_info.st_size > 0)
		{
			if (!metadata.etag.empty() || metadata.content_length > 0)
			{
				printf("--> Saving download metadata for resume validation\n");
				saveDownloadMetadata(downloadPath, metadata);
			}
		}
		
		if (resume)
		{
			printf("--> Resume failed. File may have changed on server. Try downloading without --resume\n");
		}
	}
	else
	{
		// Download succeeded, clean up any metadata file
		std::string metapath = getMetadataPath(downloadPath);
		std::remove(metapath.c_str());
	}
	
	return success;
}

bool Package::downloadZip2(std::string_view tmp_path, float*, bool resume, int zipIndex, int zipTotal) const
{
	if (this->zipUrl2.empty()) {
		return false; // no second zip, nothing to do
	}

	if (libget_status_callback != nullptr)
		libget_status_callback(STATUS_DOWNLOADING, zipIndex, zipTotal);

	printf("--> Downloading second zip for %s to %s%s\n", this->pkg_name.c_str(), tmp_path.data(), resume ? " (resuming)" : "");

	// use a different temp filename to avoid overwriting the first zip
	std::string downloadPath = std::string(tmp_path) + this->pkg_name + "_2.zip";

	download_metadata_t metadata = {};

	// find out this individual zip's real size via a lightweight HEAD request.
	// NOTE: we can't use this->download_size here -- that field comes from
	// repo.json's "filesize", which is the COMBINED total across all of this
	// package's zips, not the size of this one file.
	download_metadata_t remote_metadata = {};
	if (getRemoteFileMetadata(this->zipUrl2, &remote_metadata))
		metadata.content_length = remote_metadata.content_length;

	bool success = downloadFileToDiskWithMetadata(this->zipUrl2, downloadPath, resume, &metadata);

	if (!success)
	{
		struct stat file_info = {};
		if (stat(downloadPath.c_str(), &file_info) == 0 && file_info.st_size > 0)
		{
			if (!metadata.etag.empty() || metadata.content_length > 0)
			{
				printf("--> Saving download metadata for resume validation\n");
				saveDownloadMetadata(downloadPath, metadata);
			}
		}

		if (resume)
		{
			printf("--> Resume failed. File may have changed on server. Try downloading without --resume\n");
		}
	}
	else
	{
		std::string metapath = getMetadataPath(downloadPath);
		std::remove(metapath.c_str());
	}

	return success;
}

std::string Package::getUrlFileExt() const
{
	std::string urlEnding = ".zip"; // assume zip

	auto zipUrl = this->mRepo->getZipUrl(*this);

	if (!zipUrl.ends_with(".zip")) { // only do something if it's not a .zip already
		auto lastDotPos = zipUrl.find_last_of(".");
		if (lastDotPos != std::string::npos) {
			// slash found, grab the file ending
			std::string ending = zipUrl.substr(lastDotPos);
			urlEnding = ending;
			// printf("--> Found file ending: %s\n", urlEnding.c_str());
		}
	}

	return urlEnding;
}

// This method returns 0 through 100 representing how much of the file is downloaded, or 
// returns negative for a partial download not being possible. It can be called before passing resume=true
// to downloadZip()
int Package::hasPartialDownload(std::string_view tmp_path) const
{
	std::string downloadPath = std::string(tmp_path) + this->pkg_name + getUrlFileExt();
	struct stat file_info = {};
	
	// File must exist and not be empty
	if (stat(downloadPath.c_str(), &file_info) == 0 && file_info.st_size > 0)
	{
		// do we have any existing metadata?
		download_metadata_t saved_metadata = {};
		bool has_saved_metadata = loadDownloadMetadata(downloadPath, &saved_metadata);
		
		// validate whatever we can against the current headers (in case the file changed, eg on a new update)
		if (has_saved_metadata && !saved_metadata.etag.empty())
		{
			auto zipUrl = this->mRepo->getZipUrl(*this);
			if (!zipUrl.empty())
			{
				download_metadata_t remote_metadata = {};
				if (getRemoteFileMetadata(zipUrl, &remote_metadata))
				{
					// etag check
					if (!remote_metadata.etag.empty() && remote_metadata.etag != saved_metadata.etag)
					{
						printf("--> Warning: Remote file ETag changed (was %s, now %s)\n", 
							   saved_metadata.etag.c_str(), remote_metadata.etag.c_str());
						return -1;
					}
					
					// content length check
					if (remote_metadata.content_length > 0 && saved_metadata.content_length > 0 &&
						remote_metadata.content_length != saved_metadata.content_length)
					{
						printf("--> Warning: Remote file size changed (was %ld, now %ld)\n",
							   saved_metadata.content_length, remote_metadata.content_length);
						return -1;
					}
				}
			}
		}
		
		// How far along was the download given our partial?
		if (this->download_size > 0)
		{
			int percentage = (int)((file_info.st_size * 100) / this->download_size);
			return (percentage >= 100) ? 99 : percentage; // 100 would be misleading
		}
		else
		{
			// total size may not always be available, fallback just return 1%
			return 1;
		}
	}
	
	return -1; // cannot resume!
}

long Package::getPartialDownloadSize(std::string_view tmp_path) const
{
	std::string downloadPath = std::string(tmp_path) + this->pkg_name + getUrlFileExt();
	struct stat file_info = {};
	
	if (stat(downloadPath.c_str(), &file_info) == 0)
	{
		return file_info.st_size;
	}
	
	return 0;
}

bool Package::install(const std::string& pkg_path, const std::string& tmp_path, int zipIndex, int zipTotal)
{
	printf("Going to install %s\n", this->pkg_name.c_str());
	// assumes that download was called first
	if (libget_status_callback != nullptr)
		libget_status_callback(STATUS_ANALYZING, zipIndex, zipTotal);

	if (networking_callback != nullptr)
		networking_callback(nullptr, 1.0);

	std::string downloadedFilePath = tmp_path + this->pkg_name + getUrlFileExt();

	// Automatically delete the downloaded zip when this function exits,
	// whether it succeeds or fails (RAII guard).
	struct ZipGuard {
		const std::string& path;
		~ZipGuard() { std::remove(path.c_str()); }
	} zipGuard{ downloadedFilePath };

#ifdef NETWORK_MOCK
	// for network mocking, copy over a /mock.zip to the expected download path
	cp(ROOT_PATH "mock.zip", (downloadedFilePath).c_str());
#endif

	// check file size to see if it's 0 bytes
	struct stat sbuff = {};
	stat((downloadedFilePath).c_str(), &sbuff);
	if (sbuff.st_size == 0)
	{
		printf("--> ERROR: Downloaded file is empty\n");
		return false;
	}

	printf("--> Downloaded file size: %lld\n", (long long)sbuff.st_size);

	// our internal path of where the manifest will be
	std::string ManifestPathInternal = "manifest.install";
	std::string ManifestPath = pkg_path + this->pkg_name + "/" + ManifestPathInternal;

	// before we uninstall, open up the current manifest, and get all the files in it
	// (later we will remove any that aren't in the new manifest)
	Manifest existingManifest(ManifestPath, ROOT_PATH);

	std::unordered_set<std::string> existing_package_paths;
	if (existingManifest.isValid() && manifest.isValid())
	{
		// go through its paths, add them our existing set
		for (const auto& entry : manifest.getEntries())
		{
			ManifestOp op = entry.operation;
			if (op == MUPDATE || op == MEXTRACT)
			{
				existing_package_paths.insert(entry.path);
			}
		}
	}

	printf("--> Existing manifest valid: %d\n", existingManifest.isValid());
	//! Open the Zip file
	UnZip HomebrewZip(downloadedFilePath);
	printf("--> Opened Zip file\n");

	// location of the info.json within the zip
	std::string jsonPathInternal = "info.json";
	std::string jsonPath = pkg_path + this->pkg_name + "/" + jsonPathInternal;
	
	printf("--> Extracting to %s\n", pkg_path.c_str());
	//! Check if it's a valid Zip file
	if (HomebrewZip.IsValid())
	{
		printf("--> Valid Zip file\n");
		//! First extract the Manifest
		HomebrewZip.ExtractFile(ManifestPathInternal, ManifestPath);

		//! Then extract the info.json file (to know what version we have installed and stuff)
		HomebrewZip.ExtractFile(jsonPathInternal, jsonPath);
	} else {
		printf("--> NOTICE: Downloaded file is not a valid zip, just copying to SD root\n");
		// TODO: support other file types, copying to their destinations
	}

	this->manifest = Manifest(ManifestPath, ROOT_PATH);

	printf("--> Manifest valid: %d\n", manifest.isValid());
	if (!manifest.isValid() && manifest.isFakeManifestPossible())
	{
		printf("--> ERROR: Manifest invalid/doesn't exist but recoverable\n");
#ifndef NETWORK_MOCK
		printf("--> Manifest invalid/doesn't exist but recoverable, generating pseudo-manifest\n");
		if (HomebrewZip.IsValid())
		{
			printf("HB zip is valid\n");
			// generate a pseudo-manifest from the zip file
			this->manifest = Manifest(HomebrewZip.PathDump(), ROOT_PATH);
		} else {
			printf("Not a zip but going for it\n");
			// we're not a zip, so just put our one file path in the manifest

			// since we don't know where to put the files, put them in a default app location
			// #if defined(__WIIU__)
			// 	platformDefault = "wiiu/apps/";
			// #elif defined(WII)
			// 	platformDefault = "apps/";
			// #elif defined(SWITCH)
			// 	platformDefault = "switch/";
			// #elif defined(_3DS)
			// 	platformDefault = "3ds/";
			// #endif

			std::string platformDefault = "";
			std::string ext = getUrlFileExt();
			if (ext == ".3dsx") {
				platformDefault = "3ds/";
			} else if (ext == ".cia") {
				// TODO: where should these go? they need a post install step
			} else if (ext == ".nro") {
				platformDefault = "switch/";
			} else if (ext == ".rpx" || ext == ".wuhb") {
				platformDefault = "wiiu/apps/";
			} else {
				// assume wii format
				platformDefault = "apps/";
			}

			printf("Continuing with %s\n", platformDefault.c_str());
			std::string destFilePath = platformDefault + this->pkg_name + ext;
			std::vector<std::string> entries = { destFilePath };
			this->manifest = Manifest(entries, ROOT_PATH);
		}

		// write the pseudo-manifest to the internal package .get directory
		mkpath((pkg_path + this->pkg_name).c_str());

		std::ofstream pseudomanifest(ManifestPath);
		printf("--> Writing pseudo-manifest to %s\n", ManifestPath.c_str());
		for (const auto& entry : manifest.getEntries()) {
			pseudomanifest << entry.raw << std::endl;
		}
		pseudomanifest.close();

		// write a pseudo-info.json here too
		// TODO: load other attributes from the package, besides version
		printf("--> Writing pseudo-info.json to %s\n", jsonPath.c_str());
		std::ofstream pseudojson(jsonPath);
		pseudojson << "{\"version\":\"" << this->version << "\"}" << std::endl;
		pseudojson.close();
#endif
	}

	std::unordered_set<std::string> incoming_package_paths;

	if (manifest.isValid() && HomebrewZip.IsValid())
	{
		// get all file info from within the zip, for every path
		auto infoMap = HomebrewZip.GetPathToFilePosMapping();

		if (libget_status_callback != nullptr)
			libget_status_callback(STATUS_INSTALLING, zipIndex, zipTotal);

		int i = 0;
		const auto& entries = manifest.getEntries();
		for (const auto& entry : entries)
		{
			if (networking_callback != nullptr) {
				double progress = (double)(i + 1) / (double)entries.size();
				networking_callback(nullptr, progress);
			}

			i++;

			std::string Path = entry.zip_path;
			std::string ExtractPath = entry.path;
			auto pathCStr = Path.c_str();
			auto ePathCStr = ExtractPath.c_str();

			// track this specific file for later, when we remove files that we don't have entries for
			incoming_package_paths.insert(ExtractPath);

			// lookup this path from our map, to get its file info
			auto mapResult = infoMap.find(Path);
			if (mapResult == infoMap.end())
			{
				// auto onlyZipPaths = HomebrewZip.PathDump();
				// for (auto zipPath : onlyZipPaths)
				// {
				// 	printf("zip path: %s\n", zipPath.c_str());
				// }
				printf("--> ERROR: Could not find [%s] path in zip file\n", pathCStr);
				continue;
			}

			auto filePos = mapResult->second;

			int resp = 0;
			switch (entry.operation)
			{
			case MEXTRACT:
				//! Simply Extract, with no checks or anything, won't be deleted upon removal
				info("%s : EXTRACT\n", pathCStr);
				resp = HomebrewZip.Extract(ePathCStr, filePos);
				break;
			case MUPDATE:
				info("%s : UPDATE\n", pathCStr);
				resp = HomebrewZip.Extract(ePathCStr, filePos);
				break;
			case MGET:
			{
				info("%s : GET\n", pathCStr);
				struct stat sbuff = {};
				if (stat(ePathCStr, &sbuff) != 0) //! File doesn't exist, extract
					resp = HomebrewZip.Extract(ePathCStr, filePos);
				else
					info("File already exists, skipping...");
				break;
			}
			default:
				info("%s : NOP\n", ePathCStr);
				break;
			}

			if (resp < 0)
			{
				printf("--> Some issue happened while extracting! Error: %d\n", resp);
				return false;
			}
		}

		// done installing new files, go through the remaining files that we didn't just visit
		// and remove them (files that WERE in our old manifest, and AREN'T in the new one we got)
		for (auto& path : existing_package_paths)
		{
			// only continue if it's not in our incoming package path set
			if (incoming_package_paths.find(path) == incoming_package_paths.end())
			{
				std::remove(path.c_str());
				// printf("REMOVING: %s\n", path.c_str());
			}
		}
	}
	else
	{
		//! Extract the whole zip
		//		printf("No manifest found: extracting the Zip\n");
		//		HomebrewZip.ExtractAll("sdroot/");
		// TODO: generate a manifest here, it's needed for deletion

		if (!HomebrewZip.IsValid())
		{
			// our zip was no good, so just copy over the file to the destination
			// it's the first file in the pseudo-manifest
			
			// make a folder for the base name of the target file
			auto containingDir = dir_name(manifest.getEntries().front().path);
			mkpath(containingDir.c_str());

			auto firstEntry = manifest.getEntries().front();
			rename(downloadedFilePath.c_str(), firstEntry.path.c_str());
			printf("--> Moved %s to %s\n", downloadedFilePath.c_str(), firstEntry.path.c_str());
		}
		else if (!manifest.isFakeManifestPossible())
		{
			printf("--> Invalid/No manifest file found (or error writing manifest download)! Refusing to extract.\n");
			return false;
		}
	}

	return true;
}

bool Package::downloadZip3(std::string_view tmp_path, float*, bool resume, int zipIndex, int zipTotal) const
{
	if (this->zipUrl3.empty())
		return false;

	if (libget_status_callback != nullptr)
		libget_status_callback(STATUS_DOWNLOADING, zipIndex, zipTotal);

	printf("--> Downloading third zip for %s to %s%s\n", this->pkg_name.c_str(), tmp_path.data(), resume ? " (resuming)" : "");

	std::string downloadPath = std::string(tmp_path) + this->pkg_name + "_3.zip";
	download_metadata_t metadata = {};

	// see downloadZip2 for why this can't come from repo.json's "filesize"
	download_metadata_t remote_metadata = {};
	if (getRemoteFileMetadata(this->zipUrl3, &remote_metadata))
		metadata.content_length = remote_metadata.content_length;

	bool success = downloadFileToDiskWithMetadata(this->zipUrl3, downloadPath, resume, &metadata);

	if (!success)
	{
		struct stat file_info = {};
		if (stat(downloadPath.c_str(), &file_info) == 0 && file_info.st_size > 0)
		{
			if (!metadata.etag.empty() || metadata.content_length > 0)
			{
				printf("--> Saving download metadata for resume validation\n");
				saveDownloadMetadata(downloadPath, metadata);
			}
		}
		if (resume)
			printf("--> Resume failed. File may have changed on server. Try downloading without --resume\n");
	}
	else
	{
		std::string metapath = getMetadataPath(downloadPath);
		std::remove(metapath.c_str());
	}

	return success;
}

bool Package::downloadZip4(std::string_view tmp_path, float*, bool resume, int zipIndex, int zipTotal) const
{
	if (this->zipUrl4.empty())
		return false;

	if (libget_status_callback != nullptr)
		libget_status_callback(STATUS_DOWNLOADING, zipIndex, zipTotal);

	printf("--> Downloading fourth zip for %s to %s%s\n", this->pkg_name.c_str(), tmp_path.data(), resume ? " (resuming)" : "");

	std::string downloadPath = std::string(tmp_path) + this->pkg_name + "_4.zip";
	download_metadata_t metadata = {};

	// see downloadZip2 for why this can't come from repo.json's "filesize"
	download_metadata_t remote_metadata = {};
	if (getRemoteFileMetadata(this->zipUrl4, &remote_metadata))
		metadata.content_length = remote_metadata.content_length;

	bool success = downloadFileToDiskWithMetadata(this->zipUrl4, downloadPath, resume, &metadata);

	if (!success)
	{
		struct stat file_info = {};
		if (stat(downloadPath.c_str(), &file_info) == 0 && file_info.st_size > 0)
		{
			if (!metadata.etag.empty() || metadata.content_length > 0)
			{
				printf("--> Saving download metadata for resume validation\n");
				saveDownloadMetadata(downloadPath, metadata);
			}
		}
		if (resume)
			printf("--> Resume failed. File may have changed on server. Try downloading without --resume\n");
	}
	else
	{
		std::string metapath = getMetadataPath(downloadPath);
		std::remove(metapath.c_str());
	}

	return success;
}

bool Package::install2(const std::string& pkg_path, const std::string& tmp_path, int zipIndex, int zipTotal)
{
	if (this->zipUrl2.empty())
		return true; // no second zip, nothing to do

	printf("Going to install second zip for %s\n", this->pkg_name.c_str());

	if (libget_status_callback != nullptr)
		libget_status_callback(STATUS_INSTALLING, zipIndex, zipTotal);

	// forzar un redibujado inmediato para que el cambio de texto a
	// "Instalando... (2/2)" se vea reflejado en pantalla de inmediato,
	// en vez de quedar congelado con el ultimo frame de la descarga
	if (networking_callback != nullptr)
		networking_callback(nullptr, 0.0);  // resetea la barra a 0% al iniciar extraccion

	std::string downloadedFilePath = tmp_path + this->pkg_name + "_2.zip";

	struct ZipGuard {
		const std::string& path;
		~ZipGuard() { std::remove(path.c_str()); }
	} zipGuard{ downloadedFilePath };

	struct stat sbuff = {};
	stat(downloadedFilePath.c_str(), &sbuff);
	if (sbuff.st_size == 0)
	{
		printf("--> ERROR: Second downloaded file is empty\n");
		return false;
	}

	UnZip HomebrewZip(downloadedFilePath);
	if (!HomebrewZip.IsValid())
	{
		printf("--> ERROR: Second downloaded file is not a valid zip\n");
		return false;
	}

	// extract all files from the second zip directly, no manifest needed
	HomebrewZip.ExtractAllWithProgress(ROOT_PATH);

	printf("--> Second zip installed for %s\n", this->pkg_name.c_str());
	return true;
}

bool Package::install3(const std::string& pkg_path, const std::string& tmp_path, int zipIndex, int zipTotal)
{
	if (this->zipUrl3.empty())
		return true;

	printf("Going to install third zip for %s\n", this->pkg_name.c_str());

	if (libget_status_callback != nullptr)
		libget_status_callback(STATUS_INSTALLING, zipIndex, zipTotal);

	// forzar redibujado inmediato del texto de estado
	if (networking_callback != nullptr)
		networking_callback(nullptr, 0.0);  // resetea la barra a 0% al iniciar extraccion

	std::string downloadedFilePath = tmp_path + this->pkg_name + "_3.zip";

	struct ZipGuard {
		const std::string& path;
		~ZipGuard() { std::remove(path.c_str()); }
	} zipGuard{ downloadedFilePath };

	struct stat sbuff = {};
	stat(downloadedFilePath.c_str(), &sbuff);
	if (sbuff.st_size == 0)
	{
		printf("--> ERROR: Third downloaded file is empty\n");
		return false;
	}

	UnZip HomebrewZip(downloadedFilePath);
	if (!HomebrewZip.IsValid())
	{
		printf("--> ERROR: Third downloaded file is not a valid zip\n");
		return false;
	}

	HomebrewZip.ExtractAllWithProgress(ROOT_PATH);

	printf("--> Third zip installed for %s\n", this->pkg_name.c_str());
	return true;
}

bool Package::install4(const std::string& pkg_path, const std::string& tmp_path, int zipIndex, int zipTotal)
{
	if (this->zipUrl4.empty())
		return true;

	printf("Going to install fourth zip for %s\n", this->pkg_name.c_str());

	if (libget_status_callback != nullptr)
		libget_status_callback(STATUS_INSTALLING, zipIndex, zipTotal);

	// forzar redibujado inmediato del texto de estado
	if (networking_callback != nullptr)
		networking_callback(nullptr, 0.0);  // resetea la barra a 0% al iniciar extraccion

	std::string downloadedFilePath = tmp_path + this->pkg_name + "_4.zip";

	struct ZipGuard {
		const std::string& path;
		~ZipGuard() { std::remove(path.c_str()); }
	} zipGuard{ downloadedFilePath };

	struct stat sbuff = {};
	stat(downloadedFilePath.c_str(), &sbuff);
	if (sbuff.st_size == 0)
	{
		printf("--> ERROR: Fourth downloaded file is empty\n");
		return false;
	}

	UnZip HomebrewZip(downloadedFilePath);
	if (!HomebrewZip.IsValid())
	{
		printf("--> ERROR: Fourth downloaded file is not a valid zip\n");
		return false;
	}

	HomebrewZip.ExtractAllWithProgress(ROOT_PATH);

	printf("--> Fourth zip installed for %s\n", this->pkg_name.c_str());
	return true;
}

bool Package::remove(std::string_view pkg_path)
{
	if (libget_status_callback != nullptr)
		libget_status_callback(STATUS_REMOVING, 1, 1);

	// perform an uninstall of the current package, parsing the cached metadata
	std::string ManifestPathInternal = "manifest.install";
	std::string ManifestPath = std::string(pkg_path) + this->pkg_name + "/" + ManifestPathInternal;

	info("HomebrewManager::Delete\n");
	std::unordered_set<std::string> uniq_folders;

	//! Parse the manifest
	info("Parsing the Manifest\n");
	if (!manifest.isValid())
	{
		this->manifest = Manifest(ManifestPath, ROOT_PATH); // Load and parse manifest if not yet done
	}
	if (this->manifest.isValid())
	{
		int i = 0;
		const auto& entries = manifest.getEntries();
		for (const auto& entry : entries)
		{
			if (networking_callback != nullptr) {
				double progress = (double)(i + 1) / (double)entries.size();
				networking_callback(nullptr, progress);
			}
			i++;
			const std::string& DeletePath = entry.path;

			// the current directory
			std::string cur_dir = dir_name(DeletePath);
			uniq_folders.insert(cur_dir);

			ManifestOp op = entry.operation;
			if (op != NOP && op != MEXTRACT) // get, upgrade, and local
			{
				info("Removing %s\n", DeletePath.c_str());
				std::remove(DeletePath.c_str());
			}
		}
	}
	else
	{
		printf("--> ERROR: Manifest missing or invalid at %s\n", ManifestPath.c_str());
		return false;
	}

	// sort unique folders from longest to shortest
	std::vector<std::string> folders;
	for (auto& folder : uniq_folders)
	{
		folders.push_back(folder);
	}
	std::sort(folders.begin(), folders.end(), compareLen);

	std::vector<std::string> intermediate_folders;

	// rmdir (only works if folders are empty!) out all uniq dirs...
	std::string fsroot(ROOT_PATH);
	for (auto& folder : folders)
	{
		auto parent = dir_name(folder);
		while (!parent.empty())
		{
			std::cout << "processing... " << parent << "\n";
			if ((uniq_folders.find(parent) == uniq_folders.end()) && (parent.length() > fsroot.length()))
			{
				std::cout << "adding " << parent << "\n";

				// folder not already seen, track it
				uniq_folders.insert(parent);
				intermediate_folders.push_back(parent);
			}
			parent = dir_name(parent);
		}
	}

	// have to re-add these outside of the loop because we can't
	// modify the vector while iterating through it
	for (auto& folder : intermediate_folders)
		folders.push_back(folder);

	// re-sort it
	std::sort(folders.begin(), folders.end(), compareLen);

	for (auto& folder : folders)
	{
		rmdir(folder.c_str());
	}

	printf("--> Removing manifest...\n");

	std::remove(ManifestPath.c_str());
	auto full_pkg_path = std::string(pkg_path) + this->pkg_name;
	std::remove((full_pkg_path + "/info.json").c_str());
	std::remove((full_pkg_path + "/icon.jpg").c_str()); // clean up icon if present
	std::remove((full_pkg_path + "/icon.png").c_str()); // clean up legacy png icon, if present from before the jpg migration

	rmdir((std::string(pkg_path) + this->pkg_name).c_str());

	// package removed, clean up empty directories
	// TODO: potentially prompt user to remove some known config files for a given package
	// see: https://github.com/vgmoose/get/issues/1
	// remove_empty_dirs(ROOT_PATH, 0);

	printf("--> Homebrew removed\n");

	return true;
}

void Package::updateStatus(const std::string& pkg_path)
{
	// check if the manifest for this package exists
	std::string ManifestPathInternal = "manifest.install";
	std::string ManifestPath = pkg_path + this->pkg_name + "/" + ManifestPathInternal;

	struct stat sbuff = {};
	if (stat(ManifestPath.c_str(), &sbuff) == 0)
	{
		// manifest exists, we are at least installed
		this->status = INSTALLED;

		this->manifest = Manifest(ManifestPath, ROOT_PATH);
	}

	// check for info.json, parse version out of it
	// and compare against the package's to know whether
	// it's an update or not
	std::string jsonPathInternal = "info.json";
	std::string jsonPath = pkg_path + this->pkg_name + "/" + jsonPathInternal;

	if (INSTALLED && stat(jsonPath.c_str(), &sbuff) == 0)
	{
		// pull out the version number and check if it's
		// different than the one on the repo
		std::ifstream ifs(jsonPath.c_str());
		rapidjson::IStreamWrapper isw(ifs);

		if (!ifs.good())
		{
			printf("--> Could not locate %s", jsonPath.c_str());
			this->status = UPDATE; // issue opening info.json, assume update
			return;
		}

		rapidjson::Document doc;
		rapidjson::ParseResult ok = doc.ParseStream(isw);
		std::string tmpVersion;

		if (ok && doc.HasMember("version"))
		{
			const rapidjson::Value& info_doc = doc["version"];
			tmpVersion = info_doc.GetString();
		}
		else
			tmpVersion = "0.0.0";

		if (tmpVersion != this->version)
			this->status = UPDATE;

		// we're eithe ran update or an install at this point
		return;
	}
	else if (this->status == INSTALLED)
	{
		this->status = UPDATE; // manifest, but no info, always update
		return;
	}

	// if we're down here, and it's not a local package
	// already, it's probably a get package (package was
	// available, but the manifest wasn't installed)
	if (this->status != LOCAL)
		this->status = GET;

	// check for any homebrew that may have been previously installed
	// TODO: see https://github.com/vgmoose/hb-appstore/issues/20
	this->status = this->isPreviouslyInstalled();
}

int Package::isPreviouslyInstalled()
{
	// TODO: check for and scan Switch NRO files
#if defined(__WIIU__)
	// we're on a Wii U, so let's check for any HBL meta.xml files that match this package's name,
	// and if it exists check the version based on that
	// TODO: check for and scan WUHB files
	TiXmlDocument xmlDoc((std::string(ROOT_PATH) + "wiiu/apps/" + this->pkg_name + "/meta.xml").c_str());
	bool xmlExists = xmlDoc.LoadFile();

	if (xmlExists)
	{
		TiXmlElement* appNode = xmlDoc.FirstChildElement("app");
		if (appNode)
		{
			TiXmlElement* node = appNode->FirstChildElement("version");
			if (node && node->FirstChild() && node->FirstChild()->Value())
			{
				// version exists, we should compare the value to the one on the server (this package)
				if (this->version != node->FirstChild()->Value())
					return UPDATE;
				else
					return LOCAL;
			}
		}
	}
#endif

	// since we are appstore and know that what version we're supposed to be, mark us local or updated if needed
	// TODO: make version check here dynamic, and also support other NROs or hint files
	// notice: this means that even if appstore isn't installed but is running, it will show as an update
	if (this->pkg_name == APP_SHORTNAME)
	{
		// it's app store, but wasn't detected as installed
		if (this->version == APP_VERSION)
			return LOCAL;
		else
			return UPDATE;
	}

	return this->status;
}

const char* Package::statusString() const
{
	switch (this->status)
	{
	case LOCAL:
		return "LOCAL";
	case INSTALLED:
		return "INSTALLED";
	case UPDATE:
		return "UPDATE";
	case GET:
		return "GET";
	}
	return "UNKNOWN";
}

const char* Package::statusStringDisplay() const
{
	switch (this->status)
	{
	case LOCAL:
		return "LOCAL";
	case INSTALLED:
		return "INSTALADO";
	case UPDATE:
		return "ACTUALIZAR";
	case GET:
		return "OBTENER";
	}
	return "DESCONOCIDO";
}

std::string Package::getIconUrl() const
{
	// ask the parent repo for the icon url TODO: some fallback?
	if (this->mRepo == nullptr)
	{
		printf("--> ERROR: Parent repo not set for package %s\n", this->pkg_name.c_str());
		return "";
	}
	return this->mRepo->getIconUrl(*this);
}

std::string Package::getBannerUrl() const
{
	return this->mRepo->getUrl() + "/packages/" + this->pkg_name + "/screen.jpg";
}

std::string Package::getScreenShotUrl(int count) const
{
	if (!this->mRepo) {
		return "";
	}
	return this->mRepo->getUrl() + "/packages/" + this->pkg_name + "/screen" + std::to_string(count) + ".jpg";
}

std::string Package::getManifestUrl() const
{
	if (!this->mRepo) {
		return "";
	}
	return this->mRepo->getUrl() + "/packages/" + this->pkg_name + "/manifest.install";
}
