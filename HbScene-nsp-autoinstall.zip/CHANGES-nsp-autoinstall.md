# Auto-instalación de NSP tras la descarga — checklist de integración

Este parche agrega el paso 3 que faltaba en tu flujo:
1. descarga (ya existía: `Get::install` → `downloadZip/2/3/4`)
2. extracción, incluyendo multi-zip (ya existía: `package.install/2/3/4`)
3. **NUEVO**: si `repo.json` trae `"instalacion": "ruta/al.nsp"`, se instala ese NSP
4. mensaje de éxito (ya existía: `AlertDialog` en `AppDetails::proceed`, ahora incluye el resultado de (3))
5. vuelta al menú (ya existía: `RootDisplay::switchSubscreen(nullptr)` en `onConfirm`)

## Archivos nuevos
- `libs/get/src/nspinstall/` — motor de instalación NSP→NCM, adaptado del `InstallEngine`
  de PortNX (namespace `nspinstall`, includes aplanados, sin dependencias del resto de PortNX).
- `libs/get/src/nspinstall/NspAutoInstall.hpp/.cpp` — capa que decide si hay algo que
  instalar y llama al motor de arriba.

## Archivos modificados
- `libs/get/src/Package.hpp` — campo `install_nsp` (+ getter) y `runtime_install_status`.
- `libs/get/src/repos/GetRepo.cpp` — parseo de la clave `"instalacion"`.
- `libs/get/src/Get.cpp` — llama a `InstallNspIfRequested()` justo después de
  terminar de descargar/extraer todos los zips, antes del `update()` final.
- `gui/AppDetails.cpp` — el popup de resultado ahora suma `runtime_install_status`.
- `gui/main.cpp` — inicializa/cierra `spl`, `splCrypto`, `ncm`, `es`, `ns`, `nsext`.

## Pendiente de tu lado (no lo pude verificar sin devkitPro/hardware)

1. **Makefile**: agregar `mbedtls` a `LIBS` (usado por `CryptoUtils.cpp` para
   `splCryptoGenerateAesKek/Key` y por `NcaStructs`/AES-XTS). Si en algún momento
   querés soportar `.ncz` dentro del nsp (poco probable para forwarders chicos
   como el de DraStic), también necesitás `zstd` — si no, podés directamente
   borrar `NszDecompressor.hpp/.cpp` del build para simplificar.
2. **Verificar que `es_ipc.c`/`ns_ext_ipc.c` no choquen** con símbolos que
   devkitPro/libnx ya exponga en tu versión de toolchain (en PortNX no chocan,
   pero confirmalo con tu versión).
3. **Probar en consola real**:
   - Caso feliz: paquete con `"instalacion"` apuntando a un forwarder válido →
     debería aparecer en el menú Home tras el popup de "Descarga exitosa".
   - Paquete SIN `"instalacion"` → debe comportarse exactamente igual que antes
     (cero llamadas a NCM/ES).
   - NSP corrupto / ruta mal escrita en `repo.json` → debe mostrar el mensaje de
     error sin tumbar HbScene ni dejar placeholders huérfanos en NCM.
4. **Storage de destino**: por ahora siempre instala a SD (`NcmStorageId_SdCard`).
   Si querés que respete el toggle de "instalar a NAND" que ya tenés en
   `BrowseTab`/`Config`, hay que pasarlo como parámetro hasta `Get::install()`.
5. **repo.json de ejemplo** (igual al de DraStic que me pasaste):
   ```json
   {
     "name": "drastic",
     "title": "DraStic DS",
     "zip_url": "https://.../DRASTIC.zip",
     "instalacion": "forwarders/Emuladores/DrasticDS/DrasticDS.nsp"
   }
   ```
