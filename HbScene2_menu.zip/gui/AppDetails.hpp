#ifndef APPDETAILS_H_
#define APPDETAILS_H_

#include "AppDetailsContent.hpp"
#include "AppCard.hpp"

class AppList;

class AppDetails : public Element
{
public:
	AppDetails(Package& package, AppList* appList, AppCard* appCard = NULL);
	~AppDetails();

	std::string getPackageDetails(Package* package);
	std::string getAction(Package* package);
	bool process(InputEvents* event);
	void render(Element* parent);
	bool launchFile(char* path, char* context);
	bool themeInstall(char* installerPath);
	void getSupported();

	CST_Color red = { 0xFF, 0x00, 0x00, 0xff };
	CST_Color gray = { 0x50, 0x50, 0x50, 0xff };
	CST_Color black = { 0x00, 0x00, 0x00, 0xff };
	CST_Color white = { 0xFF, 0xFF, 0xFF, 0xff };

	bool operating = false;
	Package* package = NULL;
	Get* get = NULL;
	AppList* appList = NULL;
	AppCard* appCard = NULL;
	ProgressBar* pbar = NULL;
	int highlighted = -1;

	bool canLaunch = false;

	// the callback method to update the currently displayed pop up (and variables it needs)
	static int updateCurrentlyDisplayedPopup(void* clientp, double dlnow);
	static int updatePopupStatus(int status, int num = 1, int num_total = 1);
	static int lastFrameTime;

	// cancelacion: mantener B 5 segundos mientras se descarga/extrae/instala.
	// pollCancel revisa la tecla (y atiende los eventos pendientes); force =
	// true la ignora el limitador de frecuencia. pollCancelHook es la version
	// sin argumentos que se engancha a libget (g_libget_poll).
	static void pollCancel(bool force);
	static void pollCancelHook();

	void proceed();
	void removePackage();
	void back();
	void launch();

	void moreByAuthor();
	void leaveFeedback();

	void preInstallHook();
	void postInstallHook();

	ProgressBar downloadProgress;

	// on some platform + package combinations, we need to quit after installing
	bool quitAfterInstall = false;

private:
	// true si la operacion en curso es borrar (boton Borrar, o componente ya instalado)
	bool isUninstall() const;
	// acomoda los botones en la barra inferior
	void layoutFooter();
	bool forceUninstall = false;
	bool hasRemoveBtn = false;

	Button* start = nullptr;
	TextElement* errorText = nullptr;
	Button download;
	Button removeBtn; // "Borrar" cuando hay una actualizacion pendiente
	Button cancel;
	TextElement details;
	AppDetailsContent content;
	TextElement downloadStatus;
	TextElement downloadPercent;
	TextElement cancelHint; // "Manten B 5 s para cancelar" / cuenta regresiva
};

#endif
