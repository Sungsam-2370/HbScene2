#include "GetRepo.hpp"
#include "../Utils.hpp"
#include "constants.h"
#include "rapidjson/document.h"
#include "rapidjson/error/en.h"
#include <regex>
#include <sstream>
#include <iomanip>
#include <ctime>

using namespace rapidjson;

std::vector<std::unique_ptr<Package>> GetRepo::loadPackages()
{
	std::vector<std::unique_ptr<Package>> result;

	// raw.githubusercontent.com (y CDNs similares) esta detras de una capa
	// de cache (ej. Fastly) que puede servir una version vieja de repo.json
	// durante varios minutos despues de que se publico una actualizacion.
	// Se agrega un parametro con la hora actual para que cada consulta sea
	// una URL distinta y el CDN no devuelva algo cacheado (mismo patron ya
	// usado para apoyo.json en SupporterBenefit.cpp).
	std::string directoryUrl = this->url + "/repo.json?nocache=" + std::to_string((long long)time(nullptr));

	// fetch current repository json
	std::string response;
	bool success = downloadFileToMemoryNoCache(directoryUrl, &response);

#ifdef NETWORK_MOCK
	mockPopulatePackages(&response);
#endif

	// attempt fallback to http in case of https repos failure
	if (!success && (this->url.rfind("https", 0) == 0))
	{
		printf("--> Attempting http fallback for https repo \"%s\" after loading failure\n", this->name.c_str());

		// update repo url
		this->url.replace(0, 5, "http");
		directoryUrl = this->url + "/repo.json?nocache=" + std::to_string((long long)time(nullptr));

		// retry fetch
		success = downloadFileToMemoryNoCache(directoryUrl, &response);
	}

	if (!success)
	{
		printf("--> Could not update repository metadata for \"%s\" repo!\n", this->name.c_str());
		this->loaded = false;
		return {};
	}

	if (libget_status_callback != nullptr)
		libget_status_callback(STATUS_UPDATING_STATUS, 1, 1);

	// extract out packages, append to package list
	Document doc;
	ParseResult ok = doc.Parse(response.c_str());

	if (!ok)
	{
		printf("--> JSON parse error in repo.json for %s: %s (offset %zu)\n",
			this->url.c_str(), GetParseError_En(ok.Code()), ok.Offset());
		printf("--> Response preview (first 200 chars): %.200s\n", response.c_str());
		this->loaded = false;
		return {};
	}

	if (!doc.IsObject() || !doc.HasMember("packages"))
	{
		printf("--> Invalid format in downloaded repo.json for %s\n", this->url.c_str());
		this->loaded = false;
		return {};
	}

	const Value& packages_doc = doc["packages"];

	// for every repo
	auto total = packages_doc.Size();
	for (int i = 0; i < (int)total; i++)
	{
		if (networking_callback != nullptr) {
			double progress = (double)(i + 1) / (double)total;
			networking_callback(nullptr, progress);
		}

		auto package = std::make_unique<Package>(GET);

		// TODO: use arrays and loops for parsing this info, and also check the type first

		auto& cur = packages_doc[i];

		// mostly essential attributes
		if (cur.HasMember("name"))
		{
			package->pkg_name = cur["name"].GetString();
		}
		else
		{
			printf("Missing name for package on repo, skipping\n");
			continue;
		}
		if (cur.HasMember("title"))
			package->title = cur["title"].GetString();
		else
			package->title = package->pkg_name;

		if (cur.HasMember("author"))
			package->author = cur["author"].GetString();
		if (cur.HasMember("description"))
			package->short_desc = cur["description"].GetString();
		if (cur.HasMember("details"))
			package->long_desc = std::regex_replace(cur["details"].GetString(), std::regex("\\\\n"), "\n");
		if (cur.HasMember("version"))
			package->version = cur["version"].GetString();

		// more information and details
		if (cur.HasMember("license"))
			package->license = cur["license"].GetString();
		if (cur.HasMember("changelog"))
			package->changelog = std::regex_replace(cur["changelog"].GetString(), std::regex("\\\\n"), "\n");
		if (cur.HasMember("url"))
		{
			package->url = cur["url"].GetString();
			package->sourceUrl = package->url;
		}
		if (cur.HasMember("updated"))
		{
			package->updated = cur["updated"].GetString();
			struct tm tm {};

			auto res = my_strptime(package->updated.c_str(), "%d/%m/%Y", &tm);
			if (res)
			{
				// make sure that all the time-related fields are set
				tm.tm_hour = tm.tm_min = tm.tm_sec = 0;
				package->updated_timestamp = (int)mktime(&tm);

				// also update the label to a simpler y-m-d format
				std::stringstream ss;
				ss << std::put_time(&tm, "%Y-%m-%d");
				package->updated = ss.str();
			}
		}

		// even more details
		if (cur.HasMember("app_dls"))
			package->downloads += cur["app_dls"].GetInt();
		if (cur.HasMember("web_dls"))
			package->downloads += cur["web_dls"].GetInt();
		if (cur.HasMember("extracted"))
			// convert KB to bytes
			package->extracted_size += cur["extracted"].GetUint64() * 1000;
		if (cur.HasMember("filesize"))
			package->download_size += cur["filesize"].GetUint64() * 1000; // ibid

		if (cur.HasMember("category"))
			package->category = cur["category"].GetString();
		if (cur.HasMember("binary"))
			package->binary = cur["binary"].GetString();
		if (cur.HasMember("screens"))
			package->screens = cur["screens"].GetInt();
		if (cur.HasMember("zip_url"))
			package->zipUrl = cur["zip_url"].GetString();
		if (cur.HasMember("zip_url_2"))
			package->zipUrl2 = cur["zip_url_2"].GetString();
		if (cur.HasMember("zip_url_3"))
			package->zipUrl3 = cur["zip_url_3"].GetString();
		if (cur.HasMember("zip_url_4"))
			package->zipUrl4 = cur["zip_url_4"].GetString();

		// ruta del .nsp/.nsz/.xci a instalar automaticamente tras la
		// extraccion; si no existe esta clave, install_nsps queda vacio
		// y no se instala nada. Acepta un texto ("a.nsp") o una lista
		// (["a.nsp", "b.nsz"]); se instalan en ese orden.
		if (cur.HasMember("instalacion"))
		{
			const auto& inst = cur["instalacion"];
			if (inst.IsString())
			{
				if (inst.GetStringLength() > 0)
					package->install_nsps.push_back(inst.GetString());
			}
			else if (inst.IsArray())
			{
				for (const auto& v : inst.GetArray())
					if (v.IsString() && v.GetStringLength() > 0)
						package->install_nsps.push_back(v.GetString());
			}
		}

		// instalacion directa: URL de un .nsp/.nsz que se instala mientras se
		// descarga (nunca se guarda en la SD). Es independiente de "instalacion".
		if (cur.HasMember("instalacion_directa") && cur["instalacion_directa"].IsString())
			package->direct_install_url = cur["instalacion_directa"].GetString();

		// aviso que se muestra ANTES de descargar; el usuario debe confirmar
		// (A / touch) o cancelar (B / touch). Si no existe, no se muestra nada.
		if (cur.HasMember("aviso") && cur["aviso"].IsString())
			package->notice = std::regex_replace(cur["aviso"].GetString(), std::regex("\\\\n"), "\n");

		// actualizacion incremental: URL de un zip con SOLO lo que cambio, mas
		// el info.json y el manifest.install nuevos. Si no existe, las
		// actualizaciones descargan los zips completos como siempre.
		if (cur.HasMember("actualizacion") && cur["actualizacion"].IsString())
			package->update_url = cur["actualizacion"].GetString();
		// (opcional) version instalada desde la que aplica ese zip; si la
		// version instalada es otra se descarga el zip completo
		if (cur.HasMember("actualizacion_desde") && cur["actualizacion_desde"].IsString())
			package->update_base = cur["actualizacion_desde"].GetString();

		// instruccion final post-instalacion; solo se setea si el paquete
		// realmente trae esta linea -- si no existe, queda vacio a proposito
		if (cur.HasMember("mensaje"))
			package->install_message = cur["mensaje"].GetString();
		else if (cur.HasMember("message"))
			package->install_message = cur["message"].GetString();

		result.push_back(std::move(package));
	}
	return result;
}

std::string GetRepo::getType() const
{
	return "get";
}

std::string GetRepo::getZipUrl(const Package& package) const
{
	// If the package has a direct zip URL, use it
	if (!package.zipUrl.empty())
		return package.zipUrl;

	// Get packages are in the /zips folder under the package name
	return this->url + "/zips/" + package.getPackageName() + ".zip";
}

std::string GetRepo::getIconUrl(const Package& package) const
{
	// Get icons are also just in the /packages folder
	return this->url + "/packages/" + package.getPackageName() + "/icon.jpg";
}
